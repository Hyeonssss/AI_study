from django.contrib import admin
from themes.models import Local

# Register your models here.
admin.site.register(Local)