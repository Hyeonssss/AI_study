README.txt

1. 테스트용 아이디
ID: test
PW: 1234

2. 카카오 맵 api 관련
본인의 컴퓨터에서 도메인 설정 후, 본인 키를 사용해야만 지도 작동
https://apis.map.kakao.com/

